<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection parameters
$servername = "localhost";  // Your database server
$username = "root";  // Your database username
$password = "";  // Your database password
$dbname = "clan_db";  // The database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect form data if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize form input to prevent XSS
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // Prepare SQL statement to insert data into the database
    $stmt = $conn->prepare("INSERT INTO join_requests (name, email, message) VALUES (?, ?, ?)");
    if ($stmt === false) {
        die('Error preparing the statement: ' . $conn->error);
    }

    $stmt->bind_param("sss", $name, $email, $message);

    // Execute the statement
    if ($stmt->execute()) {
        // Redirect to a success page (index.html or a dedicated success page)
        header("Location: thank_you.html");
        exit();
    } else {
        // Handle error and display a message
        echo "<script>alert('There was an error processing your form. Please try again.');</script>";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request.";
}
?>
